//
//  homeViewController.swift
//  SideMenu
//
//  Created by Pawan iOS on 05/12/2022.
//

import UIKit

protocol homeViewControllerDelegate: AnyObject{
    func didMenuTapButton()
}

class homeViewController: UIViewController {

    
    weak var delegate:homeViewControllerDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .white
        title = "Home"
        
        
        navigationItem.leftBarButtonItem = UIBarButtonItem(image: UIImage(named: "list"), style: .done, target: self, action: #selector(didMenuTapButton))
    }
    
    @objc func didMenuTapButton() {
        delegate?.didMenuTapButton()
    }
}
