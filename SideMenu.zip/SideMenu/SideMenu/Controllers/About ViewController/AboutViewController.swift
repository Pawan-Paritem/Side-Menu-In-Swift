//
//  AboutViewController.swift
//  SideMenu
//
//  Created by Pawan iOS on 05/12/2022.
//

import UIKit

class AboutViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "About"

    }


}
