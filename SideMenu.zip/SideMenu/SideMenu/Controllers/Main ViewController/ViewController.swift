//
//  ViewController.swift
//  SideMenu
//
//  Created by Pawan iOS on 05/12/2022.
//

import UIKit

enum MenuState {
    case opened
    case closed
}

class ViewController: UIViewController {

    private var menustate: MenuState = .closed
    let aboutVc = MenuViewController()
    let homeVc  = homeViewController()
    var navVC : UINavigationController?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        addChildVCs()
    }
    
    func addChildVCs() {
        // aboutViewController
        aboutVc.delegate = self
        addChild(aboutVc)
        view.addSubview(aboutVc.view)
        aboutVc.didMove(toParent: self)
        
        //homeViewController
        homeVc.delegate = self
        let navVc = UINavigationController(rootViewController: homeVc)
        addChild(navVc)
        view.addSubview(navVc.view)
        navVc.didMove(toParent: self)
        self.navVC = navVc
    }
}


extension ViewController: homeViewControllerDelegate {
    func didMenuTapButton() {
      toogleMenu(completion: nil)
    }
    
    func toogleMenu(completion:(()-> Void)?) {
        switch menustate {
        case .closed:
            UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.8, initialSpringVelocity: 0, options: .curveEaseInOut) {
                self.navVC!.view.frame.origin.x =  self.homeVc.view.frame.size.width  - 100
            } completion: { [weak self] done in
                if done {
                    self?.menustate = .opened
                   
            }
        }
        case .opened:
            UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.8, initialSpringVelocity: 0, options: .curveEaseInOut) {
                self.navVC!.view.frame.origin.x =  0
            } completion: { done in
                if done {
                    self.menustate = .closed
                    DispatchQueue.main.async {
                        completion?()
                    }
            }
        }
    }
    }
}

extension ViewController: MenuViewControllerDelegate {
    func didSelect(menuItem: MenuOptions) {
        toogleMenu { [weak self] in
            switch menuItem {
            case .Home:
                break
            case .AboutUS:
                self?.about()
            case .Rate:
                break
            case .Share:
                break
            case .setting:
                break
            }
        }
    }
    
    func about() {
        let vc  = aboutVc
        addChild(vc)
        view.addSubview(vc.view)
        vc.didMove(toParent: self)
    }
}
