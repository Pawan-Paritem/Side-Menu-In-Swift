//
//  AboutViewController.swift
//  SideMenu
//
//  Created by Pawan iOS on 05/12/2022.
//

import UIKit

protocol MenuViewControllerDelegate: AnyObject {
    func didSelect(menuItem: MenuOptions)
}

enum MenuOptions: String, CaseIterable {
    case Home  = "Home"
    case AboutUS = "About US"
    case Rate = "Rate"
    case Share = "Share App"
    case setting = "Setting"
    
    var imageName: String {
        switch self {
        case .Home:
            return "house"
        case .AboutUS:
            return "airplan"
        case .Rate:
            return "star"
        case .Share:
            return "message"
        case .setting:
            return "gear"
        }
    }
}

class MenuViewController: UIViewController {

    private let tableView: UITableView = {
        let table = UITableView()
        table.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        return table
    }()
    weak var delegate: MenuViewControllerDelegate?
    
    let bgColor = UIColor.red
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.backgroundColor = nil
        view.addSubview(tableView)
        tableView.delegate = self
        tableView.dataSource = self
        view.backgroundColor = .red
        title = "About"
        
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        tableView.frame = CGRect(x: 0 , y: Int(view.safeAreaInsets.top), width: Int(view.bounds.size.width), height: Int(view.bounds.size.height))
    }
}
extension MenuViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return MenuOptions.allCases.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = MenuOptions.allCases[indexPath.row].rawValue
        cell.imageView?.image  = UIImage(named: MenuOptions.allCases[indexPath.row].imageName)
        cell.imageView?.tintColor = .white
        cell.backgroundColor = bgColor
        cell.textLabel?.textColor = .white
        cell.contentView.backgroundColor = bgColor
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let item = MenuOptions.allCases[indexPath.row]
        delegate?.didSelect(menuItem: item)
        
        
    }
}
